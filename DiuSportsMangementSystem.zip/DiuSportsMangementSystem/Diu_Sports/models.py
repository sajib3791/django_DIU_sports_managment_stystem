from django.db import models

# Create your models here.

class Player(models.Model):
    sports = models.CharField(max_length=15, default='Sports')
    code = models.CharField(max_length=10)
    name = models.CharField(max_length=30)
    gender = models.CharField(max_length=6)
    email = models.CharField(max_length=30)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    
    class Meta:  
        db_table = "player"
    

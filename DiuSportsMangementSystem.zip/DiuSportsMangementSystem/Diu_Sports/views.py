from django.shortcuts import render, redirect
from . models import Player

def home(request):
    context ={
        "data":"Friends Forever",
        "list":['Sajib','Amrita','Amit','Shakil','Rakib']
    }
    return render(request, "home.html", context)

def aboutus(request):
    return render(request, "about.html")

def playerRegistration(request):
        if request.method == 'POST':
    
            sports = request.POST["sports"]
            code = request.POST["code"]
            name = request.POST["name"]
            gender = request.POST["gender"]
            email = request.POST["email"]
            phone = request.POST["phone"]
            address = request.POST["address"]
            
            Player(sports=sports, code=code, name=name, gender=gender, email=email, phone=phone, address=address).save()        
    
        return render(request, "registration_form.html")
    
    
def displayInfo(request):
    player = Player.objects.all()
    return render(request, 'player_info.html', {'player':player})

def destroy(request, id):  
    player = Player.objects.get(id=id) 
     
    player.delete()  
    return redirect("/player_info/")

def edit(request, id):  
    player = Player.objects.get(id=id)  
    return render(request,'edit.html', {'player':player})  

def update(request,id):
    if request.method == 'POST':
            player = Player.objects.get(id=id)
            player.sports = request.POST["sports"]
            player.code = request.POST["code"]
            player.name = request.POST["name"]
            player.gender = request.POST["gender"]
            player.email = request.POST["email"]
            player.phone = request.POST["phone"]
            player.address = request.POST["address"]
            
            player.save()   

    return redirect("/player_info/")

def jewel(request):
   
    context = {
        'value': list(range(1, 36000))
    }
    return render(request, 'jewel.html', context)
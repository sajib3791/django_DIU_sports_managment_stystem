from django.urls import path
#now import the views.py file into this code
from .views import home, playerRegistration, displayInfo, destroy, edit, update, jewel, aboutus
urlpatterns=[
    path('',home, name='home'),
    path('about/',aboutus, name='aboutus'),
    path('player_reg/', playerRegistration, name="registration"),
    path('player_info/', displayInfo, name="Information"),
    path('delete/<int:id>', destroy, name="destroy"), 
    path('edit/<int:id>', edit),  
    path('update/<int:id>', update),
    path('jewel/', jewel, name="jewel"),
]

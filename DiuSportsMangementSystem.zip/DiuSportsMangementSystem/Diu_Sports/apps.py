from django.apps import AppConfig


class DiuSportsConfig(AppConfig):
    name = 'Diu_Sports'
